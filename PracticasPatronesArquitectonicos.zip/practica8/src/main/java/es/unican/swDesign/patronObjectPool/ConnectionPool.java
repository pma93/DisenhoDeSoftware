package es.unican.swDesign.patronObjectPool;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Stack;

/**
 * Clase que define las operaciones para solicitar y devolver una conexion
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class ConnectionPool {
	//Instancia
	private static ConnectionPool theInstance;
	//Numero de conexiones del pool
	private int numConexiones;
	//Pila de conexiones 
	private Stack<Connection> conexiones;
	
	/**
	 * Metodo para obtener la instancia del pool
	 * @return theInstance 
	 */
	public static ConnectionPool getInstance() {
		if(theInstance == null) {
			theInstance = new ConnectionPool();
		}
		return theInstance;
	}
	
	/**
	 * Constructor de la clase Conexion
	 * @param numConexiones
	 */
	protected ConnectionPool() {
		this.numConexiones = 8;
		conexiones = new Stack<Connection>();
		inicializaPool();
	}
	
	/**
	 * Metodo para solicitar una conexion, si la pila esta
	 * vacia duplica su tamanho, y vuelve a crear conexiones. 
	 * @return connection
	 * @throws SQLException 
	 */
	public Connection solicitarConexion() throws SQLException {
		Connection connection = null;
		if(getConexiones().isEmpty()) {
			for(int i=0;i<numConexiones*2;i++) {
				try {
					getConexiones().add(DbConnectionHelper.createConnection());
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
			}
		} else {
			connection = getConexiones().pop();
		}
		return connection;
	}
	
	/**
	 * Metodo para anhadir una conexion si no se ha alcanzado el limite,
	 * en caso contrario se desecha
	 * @param connection
	 * @throws SQLException 
	 */
	public void getConexion(Connection connection) throws SQLException {
		if(getConexiones().size() < numConexiones) {
			getConexiones().add(connection);
		}else {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}	
		}
	}
	
	/**
	 * Metodo para la inicializacion del
	 * pool de conexiones
	 */
	private void inicializaPool() {
		for(int i=0;i<numConexiones;i++) {
			try {
				getConexiones().add(DbConnectionHelper.createConnection());
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}
	
	/**
	 * Metodo para la obtencion de la lista de conexiones
	 * @return pila de conexiones
	 */
	public Stack<Connection> getConexiones() {
		return conexiones;
	}

	/**
	 * Metodo para modificar el numero de conexiones
	 * del pool
	 * @param numConexiones
	 */
	public void setNumConexiones(int numConexiones) {
		this.numConexiones = numConexiones;
	}
}
