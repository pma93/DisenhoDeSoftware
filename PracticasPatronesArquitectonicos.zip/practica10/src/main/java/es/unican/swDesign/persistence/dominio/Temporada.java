package es.unican.swDesign.persistence.dominio;

import java.util.List;

/**
 * Clase que representa a una Temporada
 * del modelo de dominio
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class Temporada {
	private long id;
	private int numTemporada;
	private Serie serie;
	private List<Capitulo> capitulos;
}
