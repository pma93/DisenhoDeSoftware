package es.unican.swDesign.persistence.repository;

import java.sql.SQLException;
import es.unican.swDesign.persistence.dataMappers.UsuarioDataMapper;
import es.unican.swDesign.persistence.dominio.Usuario;

/**
 * Clase que implementa los metodos
 * de la interfaz del Usuario
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class UsuarioRepositoryImpl implements UsuarioRepository {
	/**
	 * Insertar un usuario en la BBDD
	 */
	public void add(Usuario u) throws SQLException {
		UsuarioDataMapper.add(u);
	}

	/**
	 * Eliminar un usuario de la BBDD
	 */
	public void delete(Usuario u) throws SQLException {
		UsuarioDataMapper.delete(u);
	}

	/**
	 * Buscar un usuario en la BBDD
	 */
	public Usuario read(long id) throws SQLException {
		return UsuarioDataMapper.read(id);
	}
}
