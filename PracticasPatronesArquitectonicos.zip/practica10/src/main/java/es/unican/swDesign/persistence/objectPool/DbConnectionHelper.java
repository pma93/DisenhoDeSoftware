package es.unican.swDesign.persistence.objectPool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.TimeZone;

/**
 * Clase para realizar una conexion
 * 
 * @author DisenhoSoftware
 */
public class DbConnectionHelper {
	// Parametros de la conexion
	protected static String username = "polaflixStdUser";
	protected static String password = "thePassword";
	protected static String databaseUrl = "jdbc:mysql://127.0.0.1:3306/polaflix";
	
	/**
	 * Metodo para crear una conexion con la BBDD
	 * @return conexion o null en caso contrario
	 * @throws SQLException
	 */
	public static Connection createConnection() throws SQLException {
		
		Connection result = null;
	
		Properties connectionProps = new Properties();
	    connectionProps.put("user", username);
	    connectionProps.put("password", password);
	    connectionProps.put("serverTimezone","UTC");
	    
	    result = DriverManager.getConnection(databaseUrl, connectionProps);

		return result;		
	}
}
