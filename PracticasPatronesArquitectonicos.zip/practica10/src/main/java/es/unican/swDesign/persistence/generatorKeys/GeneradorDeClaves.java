package es.unican.swDesign.persistence.generatorKeys;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import es.unican.swDesign.persistence.objectPool.ConnectionPool;

/**
 * Generador de claves
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class GeneradorDeClaves {
	
	//Instancia de la clase
	private static GeneradorDeClaves theInstance;
	
	public static GeneradorDeClaves getInstance() throws SQLException {
		if(theInstance == null){
			theInstance = new GeneradorDeClaves();
		}
		return theInstance;
	}
	
	/**
	 * Metodo para la obtencion del siguiente 
	 * id para la tabla cuyo nombre se pasa como parametro
	 * @param tabla
	 * @return id
	 * @throws SQLException
	 */
	public long siguienteId(String tabla) throws SQLException {
		Connection conn = ConnectionPool.getInstance().solicitarConexion();

		String sql = "SELECT contador FROM Contador_Identificador WHERE nombreTabla=?";
		String sql2 = "UPDATE Contador_Identificador set contador=? WHERE nombreTabla=?";
		long id = 0;

		try {
			PreparedStatement p = conn.prepareStatement(sql);
			p.setString(1, tabla);
			ResultSet result = p.executeQuery();
			result.next();
			id = result.getLong(1);

			p = conn.prepareStatement(sql2);
			id++;
			p.setLong(1, id);
			p.setString(2, tabla);
			p.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		ConnectionPool.getInstance().getConexion(conn);
		
		return id;
	}
}
