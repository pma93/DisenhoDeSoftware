package es.unican.swDesign.persistence.dataMappers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import es.unican.swDesign.persistence.dominio.Categoria;
import es.unican.swDesign.persistence.dominio.Serie;
import es.unican.swDesign.persistence.objectPool.ConnectionPool;

/**
 * Data Mapper para las Series que contiene la operacion 
 * para buscar una serie
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class SerieDataMapper {
	/**
	 * Metodo que permite obtener una serie de la BBDD
	 * a partir de su identificador(id)
	 * @param id
	 * @return serie
	 * @throws SQLException
	 */
	public static Serie find(long id) throws SQLException {
		Serie s = null;
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		String query = "SELECT idSerie, nombre, sinopsis, tipoSerie FROM Serie WHERE id=?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();

			rs.next();

			s = row2Serie(rs);
			ps.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		ConnectionPool.getInstance().getConexion(conn);
				
		return s;
	}  
	
	/**
	 * Metodo que permite transformar una fila
	 * en un elemento serie
	 * @param rs
	 * @return serie
	 * @throws SQLException
	 */
	private static Serie row2Serie(ResultSet rs) throws SQLException {
		long id = rs.getLong(1);
		String nombre = rs.getString(2);
		String sinopsis = rs.getString(3);
		String tipo = rs.getString(4);
		
		Categoria c = CategoriaDataMapper.find(tipo);
		Serie s = new Serie(nombre, sinopsis, c);
		s.setId(id);
		
		return s;
	}
}
