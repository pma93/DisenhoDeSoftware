package es.unican.swDesign.persistence.dominio;

import java.util.Set;

/**
 * Clase que representa a un Usuario
 * del modelo de dominio
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class Usuario {
	private long id;
	private String nombre;
	private String password;
	private String cuenta;
	
	private CuotaUsuario cuota;
	private MarcadorUltimoCapitulo ultimoCapitulo;
	private Set<MarcadorCapitulosVistos> capitulosVistos;

	protected Set<Factura> facturas;
	private Set<Visualizacion> visualizaciones;
	protected Set<Serie> empezadas;
	protected Set<Serie> pendientes;
	protected Set<Serie> terminadas;
	
	/**
	 * Constructor
	 * @param nombre
	 * @param password
	 * @param cuenta
	 * @param cuota
	 */
	public Usuario(String nombre, String password, String cuenta, CuotaUsuario cuota) {
		this.nombre = nombre;
		this.password = password;
		this.cuenta = cuenta;
		this.cuota = cuota;
	}
	
	/*Guetters y Setters*/
	
	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getCuenta() {
		return cuenta;
	}
	
	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}
	
	public CuotaUsuario getCuota() {
		return cuota;
	}
	
	public void setCuota(CuotaUsuario cuota) {
		this.cuota = cuota;
	}
	
	public Set<Visualizacion> getVisualizaciones() {
		return visualizaciones;
	}
	
	public void setVisualizaciones(Set<Visualizacion> visualizaciones) {
		this.visualizaciones = visualizaciones;
	}

	public Set<Serie> getSeriesEmpezadas() {
		return empezadas;
	}
	
	public void setSeriesEmpezadas(Set<Serie> empezadas) {
		this.empezadas = empezadas;
	}
	
	public Set<Serie> getSeriesPendientes() {
		return pendientes;
	}
	
	public void setSeriesPendientes(Set<Serie> pendientes) {
		this.pendientes = pendientes;
	}

	public Set<Serie> getSeriesTerminadas() {
		return terminadas;
	}
	
	public void setSeriesTerminadas(Set<Serie> terminadas) {
		this.terminadas = terminadas;
	}

	public Set<Factura> getFacturas() {
		return facturas;
	}
	
	public void setFacturas(Set<Factura> facturas) {
		this.facturas = facturas;
	}
	
	public MarcadorUltimoCapitulo getUltimoCapitulo() {
		return ultimoCapitulo;
	}
	
	public void setUltimoCapitulo(MarcadorUltimoCapitulo ultimoCapitulo) {
		this.ultimoCapitulo = ultimoCapitulo;
	}

	public Set<MarcadorCapitulosVistos> getCapitulosVistos() {
		return capitulosVistos;
	}

	public void setCapitulosVistos(Set<MarcadorCapitulosVistos> capitulosVistos) {
		this.capitulosVistos = capitulosVistos;
	}
}
