package es.unican.swDesign.persistence.dominio;

import java.util.Date;
import java.util.Set;

/**
 * Clase que representa a una Factura
 * del modelo de dominio
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class Factura {
	private long id;
	private Set<Visualizacion> visualizaciones;
	private Usuario usuario;
	private Date fecha;

	/**
	 * Constructor
	 * @param usuario
	 * @param fecha
	 */
	public Factura(Usuario usuario, Date fecha) {
		this.usuario = usuario;
		this.fecha = fecha;
	}

	/*Guetters y Setters*/
	
	public Set<Visualizacion> getVisualizaciones() {
		return visualizaciones;
	}
	
	public void setVisualizaciones(Set<Visualizacion> visualizaciones) {
		this.visualizaciones = visualizaciones;
	}

	public Usuario getUsuario() {
		return usuario;
	}
	
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
}
