package es.unican.swDesign.persistence.dataMappers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import es.unican.swDesign.persistence.dominio.Categoria;
import es.unican.swDesign.persistence.objectPool.ConnectionPool;

/**
 * Data Mapper para las Categorias que contiene la operacion 
 * para buscar una categoria
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class CategoriaDataMapper {
	/**
	 * Metodo que permite obtener una categoria de la BBDD
	 * a partir de su identificador(nombre)
	 * @param nombre
	 * @return categoria
	 * @throws SQLException
	 */
	public static Categoria find(String nombre) throws SQLException {
		double precio = 0;
		String query = "SELECT coste FROM CategoriaSerie WHERE nombre = ?";
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, nombre);
			ResultSet rs = ps.executeQuery();
			rs.next();
			precio = rs.getDouble(1);
			ps.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		
		ConnectionPool.getInstance().getConexion(conn);
		
		return new Categoria(nombre,precio);
	}
}
