package es.unican.swDesign.persistence.dataMappers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import es.unican.swDesign.persistence.dominio.CuotaUsuario;
import es.unican.swDesign.persistence.objectPool.ConnectionPool;

/**
 * Data Mapper para las Categorias que contiene la operacion 
 * para buscar una cuota
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class CuotaDataMapper {
	/**
	 * Metodo que permite obtener una cuota de la BBDD
	 * a partir de su identificador(nombre)
	 * @param nombre
	 * @return cuota
	 * @throws SQLException
	 */
	public static CuotaUsuario find(String nombre) throws SQLException {
		double importe = 0;
		String query = "SELECT importe FROM CuotaUsuario WHERE nombre = ?";
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, nombre);
			ResultSet rs = ps.executeQuery();
			rs.next();
			importe = rs.getDouble(1);
			ps.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		
		ConnectionPool.getInstance().getConexion(conn);
		
		return new CuotaUsuario(nombre, importe);
	}
}
