package es.unican.swDesign.persistence.dataMappers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import es.unican.swDesign.persistence.dominio.CuotaUsuario;
import es.unican.swDesign.persistence.dominio.Usuario;
import es.unican.swDesign.persistence.generatorKeys.GeneradorDeClaves;
import es.unican.swDesign.persistence.objectPool.ConnectionPool;
import es.unican.swDesign.persistence.proxy.UsuarioProxy;

/**
 * Data Mapper para los Usuarios que contiene las operaciones
 * para anhadir, borrar y buscar un usuario
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class UsuarioDataMapper {
	/**
	 * Metodo que permite anhadir un usuario a la BBDD
	 * @param u
	 * @throws SQLException
	 */
	public static void add(Usuario u) throws SQLException {
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		GeneradorDeClaves gc = GeneradorDeClaves.getInstance();
		
		long idUsuario = gc.siguienteId("Usuario");
		
		String query = "INSERT INTO Usuario(id, nombre, password, cuenta,tipoCuota) "
				+ "VALUES(?,?,?,?,?)";
		
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setLong(1, idUsuario);
			ps.setString(2, u.getNombre());
			ps.setString(3, u.getPassword());
			ps.setString(4, u.getCuenta());
			ps.setString(5, u.getCuota().getNombre());
			
			ps.executeUpdate();
			ps.close();

		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		
		ConnectionPool.getInstance().getConexion(conn);
	}

	/**
	 * Metodo que permite borrar un usuario de la BBDD
	 * @param u
	 * @throws SQLException
	 */
	public static void delete(Usuario u) throws SQLException {
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		String query = "DELETE FROM Usuario WHERE id = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setLong(1, u.getId());
			ps.executeUpdate();
			ps.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		ConnectionPool.getInstance().getConexion(conn);
	}

	/**
	 * Metodo que permite obtener un usuario de la BBDD
	 * a partir de su identificador(id)
	 * @param id
	 * @return usuario
	 * @throws SQLException
	 */
	public static Usuario read(long id)  throws SQLException{
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		Usuario u = null;
		String query = "SELECT id, nombre, password, cuenta, tipoCuota "
				+ "FROM Usuario WHERE id=?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
			rs.next();
			u = row2Usuario(rs);
			ps.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		
		ConnectionPool.getInstance().getConexion(conn);
		
		return u;
	}
	
	/**
	 * Metodo que permite transformar una fila
	 * en un elemento usuario
	 * @param rs
	 * @return usuario
	 * @throws SQLException
	 */
	private static Usuario row2Usuario(ResultSet rs) throws SQLException {
		long id = rs.getLong(1);
		String nombre = rs.getString(2);
		String password = rs.getString(3);
		String cuenta = rs.getString(4);
		String tipo = rs.getString(5);
		
		CuotaUsuario cuota = CuotaDataMapper.find(tipo);
		Usuario up = new UsuarioProxy(nombre, password, cuenta, cuota);
		up.setId(id);
		
		return up;
	}
}
