package es.unican.swDesign.persistence.repository;

import java.sql.SQLException;
import es.unican.swDesign.persistence.dominio.Usuario;

/**
 * Interfaz que contiene los metodos
 * que seran implementados por el datamapper del Usuario
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public interface UsuarioRepository {
	void add(Usuario u) throws SQLException;
	void delete(Usuario u) throws SQLException;
	Usuario read(long id) throws SQLException;
}
