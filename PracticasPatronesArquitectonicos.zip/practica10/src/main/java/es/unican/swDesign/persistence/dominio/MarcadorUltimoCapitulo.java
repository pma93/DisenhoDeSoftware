package es.unican.swDesign.persistence.dominio;

/**
 * Clase que representa a un MarcadorUltimoCapitulo
 * del modelo de dominio
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class MarcadorUltimoCapitulo {
	private Usuario usuario;
	private Temporada temporada;
	private Capitulo capitulo;
	
	/**
	 * Constructor
	 * @param usuario
	 * @param temporada
	 * @param capitulo
	 */
	public MarcadorUltimoCapitulo(Usuario usuario, Temporada temporada, Capitulo capitulo) {
		this.usuario = usuario;
		this.temporada = temporada;
		this.capitulo = capitulo;
	}

	/*Guetters y Setters*/
	
	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Temporada getTemporada() {
		return temporada;
	}

	public void setTemporada(Temporada temporada) {
		this.temporada = temporada;
	}

	public Capitulo getCapitulo() {
		return capitulo;
	}

	public void setCapitulo(Capitulo capitulo) {
		this.capitulo = capitulo;
	}

}
