package es.unican.swDesign.persistence.dataMappers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import es.unican.swDesign.persistence.dominio.Factura;
import es.unican.swDesign.persistence.dominio.Usuario;
import es.unican.swDesign.persistence.objectPool.ConnectionPool;

/**
 * Data Mapper para las Facturas que contiene la operacion 
 * para buscar una factura
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class FacturaDataMapper {
	/**
	 * Metodo que permite obtener una factura de la BBDD
	 * a partir de su identificador(id)
	 * @param id
	 * @return factura
	 * @throws SQLException
	 */
	public static Factura find(long id) throws SQLException {
		String query = "SELECT idFactura, idUsuario, fecha FROM Factura WHERE id = ?";
		Factura f = null;
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
			f = row2Factura(rs);
			rs.next();
			ps.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		
		ConnectionPool.getInstance().getConexion(conn);
		
		return f;
	}

	/**
	 * Metodo que permite transformar una fila
	 * en un elemento cuota
	 * @param rs
	 * @return factura
	 * @throws SQLException
	 */
	private static Factura row2Factura(ResultSet rs) throws SQLException {
		long id = rs.getLong(1);
		long idUs = rs.getLong(2);
		Date fecha = rs.getDate(3);
		Usuario u = UsuarioDataMapper.read(idUs); 
		
		Factura f = new Factura(u, fecha);
		f.setId(id);
		
		return f;
	}
}
