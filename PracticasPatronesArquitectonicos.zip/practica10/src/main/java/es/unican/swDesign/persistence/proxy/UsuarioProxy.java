package es.unican.swDesign.persistence.proxy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Set;

import es.unican.swDesign.persistence.dataMappers.FacturaDataMapper;
import es.unican.swDesign.persistence.dataMappers.SerieDataMapper;
import es.unican.swDesign.persistence.dominio.CuotaUsuario;
import es.unican.swDesign.persistence.dominio.Factura;
import es.unican.swDesign.persistence.dominio.Serie;
import es.unican.swDesign.persistence.dominio.Usuario;
import es.unican.swDesign.persistence.objectPool.ConnectionPool;

/**
 * Proxy del Usuario
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class UsuarioProxy extends Usuario{
	protected boolean seriesEmpezadasCargadas;
	protected boolean seriesTerminadasCargadas;
	protected boolean seriesPendientesCargadas;
	protected boolean facturasCargadas;

	/**
	 * Metodo que inicializa al proxy
	 * @param nombre
	 * @param password
	 * @param cuenta
	 * @param cuota
	 */
	public UsuarioProxy(String nombre, String password, String cuenta, CuotaUsuario cuota) {
		super(nombre, password, cuenta, cuota);
		this.seriesEmpezadasCargadas = false;
		this.seriesTerminadasCargadas = false;
		this.seriesPendientesCargadas = false;
		this.facturasCargadas = false;
	}
	
	/**
	 * Metodos para gestionar el lazy load
	 */
	
	@Override
	public Set<Serie> getSeriesEmpezadas(){
		if (!seriesEmpezadasCargadas) {
			try {
				loadSeriesEmpezadas();
				this.seriesEmpezadasCargadas = true;
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return super.getSeriesEmpezadas();
	}
	
	protected void loadSeriesEmpezadas() throws SQLException {
		loadSeriesEmpezadas("Usuario_Series", this.empezadas);
	}
	
	protected void loadSeriesEmpezadas(String table, Set<Serie> collection) throws SQLException {
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		String query = "SELECT idSerie FROM " + table +  
				"INNER JOIN Usuario u ON u.idUsuario = table.idUsuario" 
				+ "INNER JOIN Serie s ON s.idSerie = idSerie"
				+ "INNER JOIN Serie_Estado se on se.idEstado = table.idEstado"
				+ " WHERE idUsuario = " + this.getId() + "AND" + "se.estado = Empezada";
		
		PreparedStatement ps = conn.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		try {
			while(rs.next()) {
				long idSerie = rs.getLong(1);
				Serie s = SerieDataMapper.find(idSerie);
				collection.add(s);
			}

			rs.close();
			ps.close();
		
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		ConnectionPool.getInstance().getConexion(conn);
	}
	
	@Override
	public Set<Serie> getSeriesTerminadas(){
		if (!seriesTerminadasCargadas) {
			try {
				loadSeriesTerminadas();
				this.seriesTerminadasCargadas = true;
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return super.getSeriesTerminadas();
	}
	
	protected void loadSeriesTerminadas() throws SQLException {
		loadSeriesTerminadas("Usuario_Series", this.terminadas);
	}
	
	protected void loadSeriesTerminadas(String table, Set<Serie> collection) throws SQLException {
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		String query = "SELECT idSerie FROM " + table +  
				"INNER JOIN Usuario u ON u.idUsuario = table.idUsuario" 
				+ "INNER JOIN Serie s ON s.idSerie = idSerie"
				+ "INNER JOIN Serie_Estado se on se.idEstado = table.idEstado"
				+ " WHERE idUsuario = " + this.getId() + "AND" + "se.estado = Terminada";
		PreparedStatement ps = conn.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		try {
			while(rs.next()) {
				long idSerie = rs.getLong(1);
				Serie s = SerieDataMapper.find(idSerie);
				collection.add(s);
			}

			rs.close();
			ps.close();
		
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		ConnectionPool.getInstance().getConexion(conn);
	}
	
	@Override
	public Set<Serie> getSeriesPendientes(){
		if (!seriesPendientesCargadas) {
			try {
				loadSeriesPendientes();
				this.seriesPendientesCargadas = true;
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return super.getSeriesPendientes();
	}
	
	protected void loadSeriesPendientes() throws SQLException {
		loadSeriesPendientes("Usuario_Series", this.pendientes);
	}
	
	protected void loadSeriesPendientes(String table, Set<Serie> collection) throws SQLException {
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		String query = "SELECT idSerie FROM " + table +  
				"INNER JOIN Usuario u ON u.idUsuario = table.idUsuario" 
				+ "INNER JOIN Serie s ON s.idSerie = idSerie"
				+ "INNER JOIN Serie_Estado se on se.idEstado = table.idEstado"
				+ " WHERE idUsuario = " + this.getId() + "AND" + "se.estado = Pendiente";
		PreparedStatement ps = conn.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		try {
			while(rs.next()) {
				long idSerie = rs.getLong(1);
				Serie s = SerieDataMapper.find(idSerie);
				collection.add(s);
			}

			rs.close();
			ps.close();
		
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		ConnectionPool.getInstance().getConexion(conn);
	}
	
	@Override
	public Set<Factura> getFacturas() {
		if (!facturasCargadas) {
			try {
				loadFacturas();
				this.facturasCargadas = true;
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		
		return super.getFacturas();
	}

	protected void loadFacturas() throws SQLException {
		loadFacturas("Factura", this.facturas);
	}
	
	protected void loadFacturas(String table, Set<Factura> collection) throws SQLException {
		Connection conn = ConnectionPool.getInstance().solicitarConexion();
		String query = "SELECT idFactura FROM " + table +  
				" WHERE idUsuario = " + this.getId();
		PreparedStatement ps = conn.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		try {
			while(rs.next()) {
				long idFactura = rs.getLong(1);
				Factura f = FacturaDataMapper.find(idFactura);
				collection.add(f);
			}

			rs.close();
			ps.close();
		
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		ConnectionPool.getInstance().getConexion(conn);
	}
}
