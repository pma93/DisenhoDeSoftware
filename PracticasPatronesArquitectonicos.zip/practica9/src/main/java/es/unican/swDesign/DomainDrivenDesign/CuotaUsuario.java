package es.unican.swDesign.DomainDrivenDesign;

/**
 * Clase que representa a una Cuota
 * del modelo de dominio, dicha cuota
 * puede ser: Fija o Variable
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class CuotaUsuario {
	private String nombre;
	private double importe;
	
	/**
	 * Constructor
	 * @param nombre
	 * @param importe
	 */
	public CuotaUsuario(String nombre, double importe){
		this.nombre = nombre;
		this.importe = importe;
	}

	/*Guetters y Setters*/
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public double getImporte() {
		return importe;
	}
	
	public void setImporte(double importe) {
		this.importe = importe;
	}
}
