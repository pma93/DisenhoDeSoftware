package es.unican.swDesign.DomainDrivenDesign;

import java.util.Date;

/**
 * Clase que representa a una Visualizacion
 * del modelo de dominio
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class Visualizacion {
	private Date fecha;
	private Temporada temporada;
	private Capitulo capitulo;
	private double importePagado;

	/**
	 * Constructor
	 * @param fecha
	 * @param capitulo
	 */
	public Visualizacion(Date fecha, Capitulo capitulo) {
		this.fecha = fecha;
		this.capitulo = capitulo;
	}

	/*Guetters y Setters*/
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public Temporada getTemporada() {
		return temporada;
	}

	public void setTemporada(Temporada temporada) {
		this.temporada = temporada;
	}

	public Capitulo getCapitulo() {
		return capitulo;
	}
	
	public void setCapitulo(Capitulo capitulo) {
		this.capitulo = capitulo;
	}

	public double getImportePagado() {
		return importePagado;
	}
	
	public void setImportePagado(double importePagado) {
		this.importePagado = importePagado;
	}
}
