package es.unican.swDesign.DomainDrivenDesign;

/**
 * Clase que representa a un Capitulo
 * del modelo de dominio
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class Capitulo {
	private long id;
	private int numCapitulo;
	private String titulo;
	private String sinopsis;
	private String enlace;
	private Temporada temporada;
}
