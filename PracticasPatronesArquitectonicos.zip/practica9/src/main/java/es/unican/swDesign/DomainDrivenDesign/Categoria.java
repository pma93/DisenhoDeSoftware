package es.unican.swDesign.DomainDrivenDesign;

/**
 * Clase que representa a una Categoria
 * del modelo de dominio, dicha categoria
 * puede ser: Estandar, Silver o Gold
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class Categoria {
	private String nombre;
	private double precio;
}
