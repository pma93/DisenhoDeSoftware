package es.unican.swDesign.DomainDrivenDesign;

import java.util.List;

/**
 * Clase que representa a una Serie
 * del modelo de dominio
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class Serie {
	private long id;
	private String nombre;
	private String sinopsis;
	private Categoria categoria;

	private List<Temporada> temporadas;
	private List<Artista> actores;
	private List<Artista> creadores;
}
