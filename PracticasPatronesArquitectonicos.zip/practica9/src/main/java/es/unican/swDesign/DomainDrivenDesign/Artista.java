package es.unican.swDesign.DomainDrivenDesign;

/**
 * Clase que representa a un Artista
 * del modelo de dominio
 * 
 * @author Pablo Martinez Arana
 * @author Fernando Solar Iglesias
 * @author Javier Rojo Ortiz
 * @author Pablo Mallavia Carrera
 */
public class Artista {
	private long id;
	private String nombre;
	private String apellido1;
	private String apellido2;
}
